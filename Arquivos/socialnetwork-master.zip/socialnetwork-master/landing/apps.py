from django.apps import AppConfig


class LandingConfig(AppConfig):
    name = 'landing'
